<u>
    <h4 class="text-center">Your Information</h4>
</u>
<table class="table">
    <tbody>
        <tr>
            <td>Name: </td>
            <td class="text-end"><?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td class="text-end"><?php echo e($email); ?></td>
        </tr>
        <tr>
            <td>Phone: </td>
            <td class="text-end"><?php echo e($phone); ?></td>
        </tr>
    </tbody>
</table>
<?php /**PATH /home/bbfdigit/public_html/dma2023/nomination/resources/views/nomination/information.blade.php ENDPATH**/ ?>