<?php
    use App\Models\Theme;
    $theme = Theme::findOrFail(1);
?>
© <?php echo e(now()->year); ?> <?php echo e($theme->footer); ?>

<?php /**PATH /home/bbfdigit/public_html/dma2023/nomination/resources/views/footer.blade.php ENDPATH**/ ?>