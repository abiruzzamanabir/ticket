<?php
    use App\Models\Theme;
    $theme = Theme::findOrFail(1);
?>
© <?php echo e(now()->year); ?> <?php echo e($theme->footer); ?>

<?php /**PATH C:\laragon\www\ticket\resources\views/footer.blade.php ENDPATH**/ ?>