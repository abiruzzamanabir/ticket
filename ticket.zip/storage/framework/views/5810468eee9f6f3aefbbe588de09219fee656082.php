<div class="card-body">
    <?php echo $__env->make('validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('form.updateinfo', $edit->id)); ?>" method="POST"
        class="was-validated">
        <?php echo csrf_field(); ?>
        <u>
            <h5 class="text-center text-uppercase">Nominator's Details</h5>
        </u>
        <p class="text-center">Nominator's Contact Information</p>
        <div class="border p-3 shadow my-3">
            <div class="mb-2">
                <label for="validationName" class="form-label">
                    <b>Full Name <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="name" class="form-control"
                    value="<?php echo e($edit->name); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Full Name</div>
            </div>
            <div class="mb-2">
                <label for="validationName" class="form-label">
                    <b>Designation <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="designation" class="form-control"
                    value="<?php echo e($edit->designation); ?>" required>
                <div class="invalid-feedback text-uppercase">Designation of the Nominator</div>
            </div>
            <div class="mb-2">
                <label for="validationEmail" class="form-label">
                    <b>Email <span class="text-danger">*</span></b>
                </label>
                <input type="email" name="email" class="form-control"
                    value="<?php echo e($edit->email); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Agency / Organization
                    Email</div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Contact Number <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="phone" class="form-control"
                    value="<?php echo e($edit->phone); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Contact Number</div>
            </div>
            <!--<div class="mb-2">-->
            <!--    <label for="validationPhone" class="form-label">-->
            <!--        <b>Emergency Contact Number <span class="text-danger">*</span></b>-->
            <!--    </label>-->
            <!--    <input type="text" name="phone1" class="form-control"-->
            <!--        value="<?php echo e(old('phone1')); ?>" required>-->
            <!--    <div class="invalid-feedback text-uppercase">Enter Your Emergency Contact Number</div>-->
            <!--</div>-->
        </div>
        <u>
            <h5 class="text-center text-uppercase">Alternative Contact Details</h5>
        </u>
        <div class="border p-3 shadow my-3">
            <div class="mb-2">
                <label for="validationName" class="form-label">
                    <b>Full Name <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="alternative_name" class="form-control"
                    value="<?php echo e($edit->alternative_name); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Full Name</div>
            </div>
            
            
            <div class="mb-2">
                <label for="validationEmail" class="form-label">
                    <b>Email <span class="text-danger">*</span></b>
                </label>
                <input type="email" name="alternative_email" class="form-control"
                    value="<?php echo e($edit->alternative_email); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Alternative Email</div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Contact Number <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="alternative_phone" class="form-control"
                    value="<?php echo e($edit->alternative_phone); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Alternative Contact Number
                </div>
            </div>
            <!--<div class="mb-2">-->
            <!--    <label for="validationPhone" class="form-label">-->
            <!--        <b>Emergency Contact Number <span class="text-danger">*</span></b>-->
            <!--    </label>-->
            <!--    <input type="text" name="phone1" class="form-control"-->
            <!--        value="<?php echo e(old('phone1')); ?>" required>-->
            <!--    <div class="invalid-feedback text-uppercase">Enter Your Emergency Contact Number</div>-->
            <!--</div>-->
        </div>
        <u>
            <h5 class="text-center text-uppercase">Information</h5>
        </u>
        <p class="text-center text-muted">Basic information about your innovation</p>
        <div class="border p-3 shadow my-3">

            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Innovation Name <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="title" class="form-control"
                    value="<?php echo e($edit->title); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Innovation Name
                </div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Inception Year Of The Innovation<span
                            class="text-danger">*</span></b>
                </label>
                <input type="text" name="year" class="form-control"
                    value="<?php echo e($edit->year); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Inception Year Of
                    The Innovation</div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Organization <span class="text-danger">*</span></b>
                </label>
                <input list="organisations" type="text" name="organization"
                    class="form-control" value="<?php echo e($edit->organization); ?>" required>
                <datalist id="organisations">
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($invoice->name); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
                <div class="invalid-feedback text-uppercase">Enter Your Organization Name
                </div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Address <span class="text-danger">*</span></b>
                </label>
                <input type="text" name="address" class="form-control"
                    value="<?php echo e($edit->address); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your Address</div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Website (Optional)</b>
                </label>
                <input type="text" name="website" class="form-control"
                    value="<?php echo e($edit->website); ?>">
                <div class="invalid-feedback text-uppercase">Enter Your Website URL</div>
            </div>
        </div>
        <u>
            <h5 class="text-center text-uppercase">Information about the Innovation</h5>
        </u>
        <p class="text-center text-muted">Please fill up the following information</p>
        <div class="border p-3 shadow my-3">
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Select Your Innovation Category <span
                            class="text-danger">*</span></b>
                </label>
                <select name="category" class="form-select">
                    <option value="">Select Nomination Category *</option>
                    <optgroup label="Best Innovation - Finance">
                        <option <?php if($edit->category == 'Innovation in Banks'): ?> selected <?php endif; ?> value="Innovation in Banks"> &nbsp; - Innovation in Banks
                        </option>
                        <option <?php if($edit->category == 'Innovation in NBFIs'): ?> selected <?php endif; ?> value="Innovation in NBFIs"> &nbsp; - Innovation in NBFIs
                        </option>
                        <option <?php if($edit->category == 'Innovation in Other Financial Institutions'): ?> selected <?php endif; ?> value="Innovation in Other Financial Institutions"> &nbsp;
                            - Innovation in Other Financial Institutions </option>
                        <option <?php if($edit->category == 'Innovation in Insurance'): ?> selected <?php endif; ?> value="Innovation in Insurance"> &nbsp; - Innovation in
                            Insurance </option>
                    </optgroup>
                    <option <?php if($edit->category == 'Best Innovation – Fashion & Apparel'): ?> selected <?php endif; ?> value="Best Innovation – Fashion & Apparel">♢ Best Innovation –
                        Fashion & Apparel </option>
                    <option <?php if($edit->category == 'Best Innovation – Healthcare'): ?> selected <?php endif; ?> value="Best Innovation – Healthcare">♢ Best Innovation –
                        Healthcare </option>

                    <option <?php if($edit->category == 'Best Innovation - Community Engagement'): ?> selected <?php endif; ?> value="Best Innovation - Community Engagement">♢ Best
                        Innovation - Community Engagement</option>
                    <option <?php if($edit->category == 'Best Innovation – SDG Inclusion'): ?> selected <?php endif; ?> value="Best Innovation – SDG Inclusion">♢ Best Innovation – SDG
                        Inclusion</option>
                    <option <?php if($edit->category == 'Best Innovation – Agriculture Sector'): ?> selected <?php endif; ?> value="Best Innovation – Agriculture Sector">♢ Best Innovation
                        – Agriculture Sector</option>
                    <option <?php if($edit->category == 'Best Process Innovation'): ?> selected <?php endif; ?> value="Best Process Innovation">♢ Best Process Innovation
                    </option>
                    <option <?php if($edit->category == 'Best Innovation – Product Development'): ?> selected <?php endif; ?> value="Best Innovation – Product Development">♢ Best Innovation
                        – Product Development </option>
                    <option <?php if($edit->category == 'Best Start Up Innovation'): ?> selected <?php endif; ?> value="Best Start Up Innovation">♢ Best Start Up Innovation
                    </option>
                    <option <?php if($edit->category == 'Best Social Innovation'): ?> selected <?php endif; ?> value="Best Social Innovation">♢ Best Social Innovation
                    </option>
                    <option <?php if($edit->category == 'Best Innovation – Frontier Technology (Robotics, Drone, Augmented Reality, Virtual Reality, Machine Intelligence & Blockchain)'): ?> selected <?php endif; ?>
                        value="Best Innovation – Frontier Technology (Robotics, Drone, Augmented Reality, Virtual Reality, Machine Intelligence & Blockchain)">
                        ♢ Best Innovation – Frontier Technology (Robotics, Drone, Augmented
                        Reality, Virtual Reality, Machine Intelligence & Blockchain)
                    </option>
                    <optgroup label="Best Innovation – Education">
                        <option <?php if($edit->category == 'University Learning Delivery'): ?> selected <?php endif; ?> value="University Learning Delivery"> &nbsp; - University
                            Learning Delivery</option>
                        <option <?php if($edit->category == 'School Learning Delivery'): ?> selected <?php endif; ?> value="School Learning Delivery"> &nbsp; - School Learning
                            Delivery</option>
                        <option <?php if($edit->category == '3rd Party Education Innovation'): ?> selected <?php endif; ?> value="3rd Party Education Innovation"> &nbsp; - 3rd Party
                            Education Innovation</option>
                    </optgroup>
                    <option <?php if($edit->category == 'Most Innovative Tourism Solution'): ?> selected <?php endif; ?> value="Most Innovative Tourism Solution">♢ Most Innovative
                        Tourism Solution</option>
                    <option <?php if($edit->category == 'Most Innovative Solution for Disable People'): ?> selected <?php endif; ?> value="Most Innovative Solution for Disable People">♢ Most
                        Innovative Solution for Disable People</option>
                    <option <?php if($edit->category == 'Most Innovative Environmental Solution'): ?> selected <?php endif; ?> value="Most Innovative Environmental Solution">♢ Most
                        Innovative Environmental Solution</option>
                    <option <?php if($edit->category == 'Public Service Innovation'): ?> selected <?php endif; ?> value="Public Service Innovation">♢ Public Service Innovation
                    </option>
                    <optgroup label="Innovations by the Youth/Students">
                        <option <?php if($edit->category == 'Best Innovation in Robotics & AI'): ?> selected <?php endif; ?> value="Best Innovation in Robotics & AI"> &nbsp; - Best Innovation in Robotics & AI</option>
                        <option <?php if($edit->category == 'Best Innovation in Software/App Solution Development'): ?> selected <?php endif; ?> value="Best Innovation in Software/App Solution Development"> &nbsp; - Best Innovation in Software/App Solution Development</option>
                        <option <?php if($edit->category == 'Best Innovation in New Business Solutions'): ?> selected <?php endif; ?> value="Best Innovation in New Business Solutions"> &nbsp; - Best Innovation in New Business Solutions</option>
                        <option <?php if($edit->category == 'Best Innovation in Medical/Healthcare'): ?> selected <?php endif; ?> value="Best Innovation in Medical/Healthcare"> &nbsp; - Best Innovation in Medical/Healthcare</option>
                    </optgroup>
                </select>
                <div class="invalid-feedback text-uppercase">SELECT YOUR INNOVATION
                    CATEGORY</div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Type of Innovation <span
                        class="text-danger">*</span></b>
                </label>
                <input type="text" name="type" class="form-control"
                    value="<?php echo e($edit->type); ?>" required>
                <div class="invalid-feedback text-uppercase">Enter Your type of innovation
                </div>
            </div>
            <div class="mb-2">
                <label for="validationPhone" class="form-label">
                    <b>Operation Starting Date <span class="text-danger">*</span></b>
                </label>
                <input type="date" name="date" class="form-control"
                    value="<?php echo e($edit->date); ?>">
                <div class="invalid-feedback text-uppercase">Enter Your Starting Date</div>
            </div>
            <div class="mb-2">
                <label for="validationDescription"
                    class="form-label"><b>Background <span
                        class="text-danger">*</span></b></label>
                <textarea name="background" id="background" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 50 words" required><?php echo e($edit->background); ?></textarea>
                <div class="invalid-feedback">A concise description of the context of how the innovation was designed the (problem statement).</div>
                <p id="backgroundcount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_backgroundcount">0</span> | Word Left: <span
                        id="backgroundword_left">50</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription"
                    class="form-label"><b>Objective <span
                        class="text-danger">*</span></b></label>
                <textarea name="objective" id="objective" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 50 words" required><?php echo e($edit->objective); ?></textarea>
                <div class="invalid-feedback">Define specific objectives of the Innovation in the given amount of time and highlight other important factors relative to its success.</div>
                <p id="objectivecount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_objectivecount">0</span> | Word Left: <span
                        id="objectiveword_left">50</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription"
                    class="form-label"><b>Vision <span
                        class="text-danger">*</span></b></label>
                <textarea name="vision" id="vision" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 50 words" required><?php echo e($edit->vision); ?></textarea>
                <div class="invalid-feedback">What is the long-term vision of this innovation?</div>
                <p id="visioncount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_visioncount">0</span> | Word Left: <span
                        id="visionword_left">50</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription" class="form-label"><b>Innovation
                        Idea <span
                        class="text-danger">*</span></b></label>
                <textarea name="idea" id="idea" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 150 words" required><?php echo e($edit->idea); ?></textarea>
                <div class="invalid-feedback">What was the Innovation idea/concept of the innovation?</div>
                <p id="ideacount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_ideacount">0</span> | Word Left: <span
                        id="ideaword_left">150</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription"
                    class="form-label"><b>Execution <span
                        class="text-danger">*</span></b></label>
                <textarea name="execution" id="execution" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 150 words" required><?php echo e($edit->execution); ?></textarea>
                <div class="invalid-feedback">Describe the strategy implied and how it was executed. What were the challenges in execution and how were they addressed?</div>
                <p id="executioncount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_executioncount">0</span> | Word Left: <span
                        id="executionword_left">150</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription" class="form-label"><b>Value
                        Addition <span
                        class="text-danger">*</span></b></label>
                <textarea name="value_addition" id="value_addition" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 75 words" required><?php echo e($edit->value_addition); ?></textarea>
                <div class="invalid-feedback">How has the innovation added to the wellbeing of society/organization/nation?</div>
                <p id="value_additioncount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_value_additioncount">0</span> | Word Left: <span
                        id="value_additionword_left">75</span>
                </p>
            </div>
            <div class="mb-2">
                <label for="validationDescription"
                    class="form-label"><b>Result/Impact <span
                        class="text-danger">*</span></b></label>
                <textarea name="result" id="result" class="form-control" cols="10" rows="3"
                    placeholder="Not more than 100 words" required><?php echo e($edit->result); ?></textarea>
                <div class="invalid-feedback">What was/were the result/impact of the innovation? What are some of the measures of success?</div>
                <p id="resultcount" class="text-left text-center mt-2 d-none"
                    style="font-size: 10px;">
                    Word
                    Count: <span id="display_resultcount">0</span> | Word Left: <span
                        id="resultword_left">100</span>
                </p>
            </div>
            <div class="my-4">
                <label for="validationPhone" class="form-label"><b>Supporting Documents
                        Google Drive Link <span
                        class="text-danger">*</span></b></label>
                <textarea name="link" class="form-control" cols="10" rows="3"
                    placeholder="Paste the Google Drive Link Here. (Upload the necessary materials in a folder and share the link here. The contents must include: PPT, Visuals, NOC, Case AV and any other supporting documents)" required><?php echo e($edit->link); ?></textarea>
                <p class="text-danger mt-1">Disclaimer: Without proper supporting documents
                    nomination will be disqualified.</p>
            </div>
            <div class="mt-2 text-center">
                <button style="width: 120px;" type="submit"
                    class="btn btn-primary">Submit</button>
            </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\nomination\resources\views/nomination/edit.blade.php ENDPATH**/ ?>