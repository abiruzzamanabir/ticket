<?php
    use App\Models\Theme;
    $theme = Theme::findOrFail(1);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nomination Form | <?php echo e($theme->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/'.$theme->favicon)); ?>" type="image/x-icon">
    <style>
        body {
            background-color: #f2f2f2;
            background-image: url('<?php echo e(asset('assets/img/' . $theme->background)); ?>');
        }

        .container {
            max-width: 700px;
            padding: 20px;
            margin: 40px auto;
            background-color: #f2f2f2;
            border-radius: 15px;
            /* box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.1), -10px -10px 20px rgba(255, 255, 255, 0.5); */
        }

        .border {
            border-radius: 15px;
        }

        .form-control {
            background-color: #f2f2f2;
            border: none;
            border-radius: 10px;
            box-shadow: inset 6px 6px 6px rgba(0, 0, 0, 0.1), inset -6px -6px 6px rgba(255, 255, 255, 0.5);
        }

        .form-control:focus {
            outline: none;
            box-shadow: inset 4px 4px 4px rgba(0, 0, 0, 0.1), inset -4px -4px 4px rgba(255, 255, 255, 0.5);
        }

        .btn-primary {
            background-color: #65a9e6;
            border-color: #65a9e6;
            border-radius: 10px;
            box-shadow: 6px 6px 6px rgba(0, 0, 0, 0.1), -6px -6px 6px rgba(255, 255, 255, 0.5);
        }

        .btn-primary:hover {
            background-color: #5593cd;
            border-color: #5593cd;
        }

        .card {
            background-color: #f2f2f2;
            border: none;
            border-radius: 15px;
            /* box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.1), -10px -10px 20px rgba(255, 255, 255, 0.5); */
        }

        .card-header {
            background-color: #f2f2f2;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .card-footer {
            background-color: #f2f2f2;
            border-top: none;
            border-radius: 0 0 15px 15px;
        }

        h5 {
            color: #333;
        }

        label {
            color: #555;
        }

        .count {
            font-size: 10px;
            box-shadow: inset 6px 6px 6px rgba(0, 0, 0, 0.1), inset -6px -6px 6px rgba(255, 255, 255, 0.5);
            display: block;
            text-align: center;
            margin: 5px auto 20px !important;
            width: 30%;
            padding: 5px;
            border-radius: 15px;
        }
    </style>
</head>

<body>
    <div class="container shadow">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">
                <div class="card-header text-center">
                    <a href="<?php echo e($theme->url); ?>">
                        <img width="150px" src="<?php echo e(asset('assets/img/'.$theme->logo)); ?>" alt="">
                    </a>
                    <div class="time py-1" id="countdown"></div>
                </div>
                <div class="card shadow">
                    <?php
                        use Carbon\Carbon;
                        $time = Carbon::parse($theme->close);
                        $close = $time;
                    ?>
                    <?php if(Carbon::now() <= $close): ?>
                        <div class="card-body">
                            <?php echo $__env->make('validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form action="<?php echo e(route('form.store')); ?>" method="POST" class="was-validated">
                                <?php echo csrf_field(); ?>
                                <u>
                                    <h5 class="text-center text-uppercase">Personal Details</h5>
                                </u>
                                <div class="border p-3 shadow my-3">
                                    <div class="mb-2">
                                        <label for="validationName" class="form-label">
                                            <b>Full Name <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="name" class="form-control"
                                            value="<?php echo e(old('name')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Full Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationName" class="form-label">
                                            <b>Designation <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="designation" class="form-control"
                                            value="<?php echo e(old('designation')); ?>" required>
                                        <div class="invalid-feedback">Designation Of The Nominator</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Organization <span class="text-danger">*</span></b>
                                        </label>
                                        <input list="organisations" autocomplete="off" type="text"
                                            name="organization" class="form-control" value="<?php echo e(old('organization')); ?>"
                                            required>
                                        <datalist id="organisations">
                                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($invoice->name); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </datalist>
                                        <div class="invalid-feedback">Enter Your Organization Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Office Address <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="address" class="form-control"
                                            value="<?php echo e(old('address')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Office Address</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationEmail" class="form-label">
                                            <b>Email <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="email" name="email" class="form-control"
                                            value="<?php echo e(old('email')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Agency / Organization Email</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Contact Number <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="phone" class="form-control"
                                            value="<?php echo e(old('phone')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Contact Number</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Emergency Contact Number <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="phone1" class="form-control"
                                            value="<?php echo e(old('phone1')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Emergency Contact Number</div>
                                    </div>
                                </div>
                                <u>
                                    <h5 class="text-center">Campaign Details</h5>
                                </u>
                                <p class="text-center text-muted">Basic information about your campaign</p>
                                <div class="border p-3 shadow my-3">

                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Campaign Name <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="title" class="form-control"
                                            value="<?php echo e(old('title')); ?>" required>
                                        <div class="invalid-feedback">Enter Your Campaign Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Select Your Campaign Category <span class="text-danger">*</span></b>
                                        </label>
                                        <select name="category" class="form-select">
                                            <option value="">Select Campaign Category</option>
                                            <option value="Best App Marketing">Best App Marketing</option>
                                            <option value="Best Content Marketing">Best Content Marketing </option>
                                            <option value="Best Digital Campaign by New Agency ">Best Digital Campaign
                                                by New Agency </option>
                                            <option value="Best Digital Experience Marketing">Best Digital Experience
                                                Marketing</option>
                                            <option value="Best E-Commerce Platform">Best E-Commerce Platform</option>
                                            <option value="Best Integrated Digital Campaign">Best Integrated Digital
                                                Campaign</option>
                                            <option value="Best Social Campaign">Best Social Campaign</option>
                                            <option value="Best UGC">Best UGC</option>
                                            <option value="Best Use of Data & Analytics">Best Use of Data & Analytics
                                            </option>
                                            <option value="Best Use of Display">Best Use of Display</option>
                                            <option value="Best Use of Facebook">Best Use of Facebook</option>
                                            <option value="Best Use of Influencer">Best Use of Influencer</option>
                                            <option value="Best Use of Instagram">Best Use of Instagram</option>
                                            <option value="Best Use of Mobile">Best Use of Mobile</option>
                                            <option value="Best Use of PR in Digital Platform">Best Use of PR in
                                                Digital Platform</option>
                                            <option value="Best Use of Search">Best Use of Search</option>
                                            <option value="Best Use of TikTok">Best Use of TikTok</option>
                                            <option value="Best Use of Under 10 Seconds Video">Best Use of Under 10
                                                Seconds Video</option>
                                            <option
                                                value="Best Use of User Community Platform/ New Platforms/ Own Platforms">
                                                Best Use of User Community Platform/ New Platforms/ Own Platforms
                                            </option>
                                            <option value="Best Use of YouTube">Best Use of YouTube</option>
                                            <option value="Best Video">Best Video</option>
                                        </select>
                                        <div class="invalid-feedback">SELECT YOUR NOMINATION CATEGORY</div>
                                    </div>

                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Agency / Organization Name <span class="text-danger">*</span></b>
                                        </label>
                                        <input list="organisations" autocomplete="off" type="text"
                                            name="organization_name" class="form-control"
                                            value="<?php echo e(old('organization_name')); ?>" required>
                                        <datalist id="organisations">
                                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($invoice->name); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </datalist>
                                        <div class="invalid-feedback">Enter Your Agency / Organization Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Production House <span class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="production_house" class="form-control"
                                            value="<?php echo e(old('production_house')); ?>" required>
                                        <div class="invalid-feedback">Enter The Production House Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Brand Name <span
                                                    class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="brand" class="form-control"
                                            value="<?php echo e(old('brand')); ?>" required>
                                        <div class="invalid-feedback">Enter The Brand Name</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Type Of Product Or Service <span
                                                    class="text-danger">*</span></b>
                                        </label>
                                        <input type="text" name="type" class="form-control"
                                            value="<?php echo e(old('type')); ?>" required>
                                        <div class="invalid-feedback">Enter The Type Of Product Or Service</div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="validationPhone" class="form-label">
                                            <b>Campaign Duration</b>
                                        </label>
                                        <input type="text" id="daterange" name="date" class="form-control"
                                            value="<?php echo e(old('date')); ?>">
                                        <div class="invalid-feedback">Enter Your Type of Fintech Innovation</div>
                                    </div>

                                </div>
                                <u>
                                    <h5 class="text-center">Campaign Story</h5>
                                </u>
                                <p class="text-center text-muted">Please fill up the following information</p>

                                <div class="border p-3 shadow my-3">
                                    <div class="my-4">
                                        <label for="validationPhone" class="form-label">
                                            Please Share Nomination Form, PPT, NOC, Case AV, Campaign AV, Creatives, Insights, and Logo <b><u>(Template & Format
                                                    provided on the website)</u></b><span
                                                class="text-danger">*</span><br>
                                            <span class="text-danger">
                                                Please share one single google drive or dropbox link following a folder named by the campaign title with 8 subfolders – Nomination Form, PPT, NOC, Case AV, Campaign AV, Creatives, Insights, and Logo
                                            </span>
                                        </label>
                                        <input type="text" name="link" placeholder="Share links here"
                                            class="form-control" value="<?php echo e(old('link')); ?>" required>
                                        <div class="invalid-feedback">Share links here</div>
                                    </div>
                                </div>
                                <div class="mt-2 text-center">
                                    <button style="width: 120px;" type="submit"
                                        class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="card-body">
                            <h3 class="text-center text-danger">
                                Nomination submission window is now closed.
                            </h3>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer text-muted text-center">
                    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-iv3foDG0pThGh1J7P3q+d01usFSuYfbzV4F0L24hka/2sRE+dSmwyaDQnPjTzdfu" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.6.3.slim.min.js"
        integrity="sha256-ZwqZIVdD3iXNyGHbSYdsmWP//UBokj2FHAxKuSBKDSo=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            var sections = [{
                    id: "#background",
                    displayId: "#display_backgroundcount",
                    wordLeftId: "#backgroundword_left",
                    countId: "#backgroundcount",
                    maxLength: 50
                },
                {
                    id: "#objective",
                    displayId: "#display_objectivecount",
                    wordLeftId: "#objectiveword_left",
                    countId: "#objectivecount",
                    maxLength: 50
                },
                {
                    id: "#vision",
                    displayId: "#display_visioncount",
                    wordLeftId: "#visionword_left",
                    countId: "#visioncount",
                    maxLength: 50
                },
                {
                    id: "#idea",
                    displayId: "#display_ideacount",
                    wordLeftId: "#ideaword_left",
                    countId: "#ideacount",
                    maxLength: 150
                },
                {
                    id: "#execution",
                    displayId: "#display_executioncount",
                    wordLeftId: "#executionword_left",
                    countId: "#executioncount",
                    maxLength: 150
                },
                {
                    id: "#value_addition",
                    displayId: "#display_value_additioncount",
                    wordLeftId: "#value_additionword_left",
                    countId: "#value_additioncount",
                    maxLength: 75
                },
                {
                    id: "#result",
                    displayId: "#display_resultcount",
                    wordLeftId: "#resultword_left",
                    countId: "#resultcount",
                    maxLength: 75
                }
            ];

            sections.forEach(function(section) {
                $(section.id).on('input', function() {
                    var words = this.value.match(/\S+/g).length;
                    if (words > section.maxLength) {
                        var trimmed = $(this).val().split(/\s+/, section.maxLength).join(" ");
                        $(this).val(trimmed + " ");
                    } else {
                        $(section.displayId).text(words);
                        $(section.wordLeftId).text(section.maxLength - words);
                        if (words > 1) {
                            $(section.countId).removeClass('d-none');
                        } else if (words < 1) {
                            $(section.countId).addClass('d-none');
                        } else {
                            $(section.countId).addClass('d-none');
                        }
                    }
                });
            });
        });

        window.setTimeout(function() {
            $(".alert").fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 3000);
    </script>
    <?php
        $databaseDatetime = strtotime($theme->close);

        // Calculate time remaining
        $currentDatetime = time();
        $timeRemaining = $databaseDatetime - $currentDatetime;

        // Send the time remaining to the client-side JavaScript
        echo '<script>
            var timeRemaining = ' . $timeRemaining . ';
        </script>';
    ?>
    <script>
        // Receive the time remaining value from the server-side code
        var timeRemaining = <?php echo $timeRemaining; ?>;

        // Function to update the countdown timer
        function updateCountdown() {
            if (timeRemaining <= 0) {
                // The countdown has expired, you can handle this case here
                if (timeRemaining == 0) {
                    location.reload();
                }
            } else {
                var hours = Math.floor(timeRemaining / 3600);
                var minutes = Math.floor((timeRemaining % 3600) / 60);
                var seconds = timeRemaining % 60;
                var h = hours > 1 ? 'hours ' : 'hour ';
                var hz = hours < 10 ? '0' : '';
                var m = minutes > 1 ? 'minutes ' : 'minute ';
                var mz = minutes < 10 ? '0' : '';
                var s = seconds > 1 ? 'seconds ' : 'second ';
                var sz = seconds < 10 ? '0' : '';
                if (timeRemaining <= 86400) {
                    document.getElementById('countdown').innerHTML = '<p>Time Remain: ' + '<span>' + hz + hours + ' ' +
                        ': ' + '</span>' + '<span>' + mz + minutes + ' ' + ': ' + '</span>' + '<span>' + sz + seconds +
                        '</p>';
                }
                timeRemaining--;
                setTimeout(updateCountdown, 1000); // Update the countdown every second
            }
        }

        // Start the countdown
        updateCountdown();
    </script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

    <script>
        $(function() {
            var dateRangePicker = $('input[name="date"]').daterangepicker({
                opens: 'left',
                startDate: moment('05/20/2022'),
                endDate: moment('05/31/2023'),
                minDate: moment('05/20/2022'),
                maxDate: moment('05/31/2023')
            });

            dateRangePicker.on('apply.daterangepicker', function(ev, picker) {
                var startDate = picker.startDate.format('YYYY-MM-DD');
                var endDate = picker.endDate.format('YYYY-MM-DD');
                console.log("A new date selection was made: " + startDate + ' to ' + endDate);
            });
        });
    </script>
<?php /**PATH C:\laragon\www\nomination-form\resources\views/nomination/index.blade.php ENDPATH**/ ?>