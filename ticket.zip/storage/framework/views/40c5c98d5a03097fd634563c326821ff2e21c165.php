<?php
    use App\Models\Theme;
    $theme = Theme::findOrFail(1);
?>
© <?php echo e(now()->year); ?> <?php echo e($theme->footer); ?>

<?php /**PATH /home/bbfdigit/public_html/cyber-security-summit-2024/ticket/resources/views/footer.blade.php ENDPATH**/ ?>