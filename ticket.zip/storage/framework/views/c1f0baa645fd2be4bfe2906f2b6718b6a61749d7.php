<u>
    <h4 class="text-center">Your Information</h4>
</u>
<table class="table">
    <tbody>
            <tr>
                <td>Serial Number: </td>
                <td class="text-end">1</td>
            </tr>
        <tr>
            <td>Name: </td>
            <td class="text-end"><?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td class="text-end"><?php echo e($email); ?></td>
        </tr>
        <tr>
            <td>Phone: </td>
            <td class="text-end"><?php echo e($phone); ?></td>
        </tr>
    </tbody>
</table>

<?php $__currentLoopData = json_decode($members); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table class="table">
        <tbody>
            <tr>
                <td>Serial Number: </td>
                <td class="text-end"><?php echo e($index + 2); ?></td>
            </tr>
            <tr>
                <td>Name: </td>
                <td class="text-end"><?php echo e($member->member_name); ?></td>
            </tr>
            <tr>
                <td>Email: </td>
                <td class="text-end"><?php echo e($member->member_email); ?></td>
            </tr>
            <tr>
                <td>Phone: </td>
                <td class="text-end"><?php echo e($member->member_contact); ?></td>
            </tr>
        </tbody>
    </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\ticket\resources\views/nomination/information.blade.php ENDPATH**/ ?>